# עברית PRO V32

Static HTML site for Vercel. Upload `index.html` to the root of the GitHub repository. The focus center stores daily checkboxes and reading preferences locally, not in the cloud.
